# DECISIONS.md

Record every choice that the documents leave open, and every deviation from them. Format: **Date – Problem – Decision – Reason**.

## Known gaps in the documents (already decided; follow these)

| # | Gap | Decision |
|---|---|---|
| D-1 | `orders` stores only `tracking_token_hash`, but an idempotent replay of `POST /public/orders` must return the same `trackingToken`. | Derive `trackingToken = base64url(HMAC-SHA256(TRACKING_SECRET, orderId))`. Store its SHA-256 in `tracking_token_hash`. A replay recomputes the same token. |
| D-2 | No `refresh_tokens` table exists. | Use a signed, stateless refresh JWT in an HttpOnly cookie (7 days). Logout clears the cookie. Known limit: no server-side revocation. Revisit later. |
| D-3 | Translation provider not chosen (Week 4 open item). | Build a `TranslationProvider` interface. Ship a `FakeTranslationProvider` (returns text with a language prefix) and one real adapter selected by `TRANSLATION_PROVIDER` env var. Results always go through the `translations` cache table. |
| D-4 | Email provider for password reset not chosen. | Build a `Mailer` interface. In development log the reset link to the console. Add a real adapter (SMTP) later. |
| D-5 | If an item has variants, is `variantId` required when ordering? | Yes: if the item has variants, `variantId` is required; if it has none, `variantId` must be null and `base_price` is used. |
| D-6 | The doc says customers' open menus update on availability change but not which room. | Public customers join room `menu:{restaurantId}` after the QR token is validated; `menu:updated` is emitted there. |
| D-7 | `order_number` is a per-restaurant counter that grows forever. | Keep as documented (`restaurants.order_counter`). Display as `#<number>`. Optional daily reset is out of scope. |
| D-8 | Public menu caching. | Cache the public menu response in memory per `(qrToken, lang, filters)` for 5 seconds; invalidate on any menu change for that restaurant. |

## Log

(Add new entries below.)
