# QuickMenu QR – Build Kit for your coding agent

This kit turns your Week 1 to 4 documents into a step-by-step build plan for an AI coding agent (Claude Code, Cursor, Codex, Copilot Agent, Windsurf, and similar).

## What is inside

| Path | Purpose |
|---|---|
| `AGENTS.md` | Standing rules for the agent: stack, architecture rules, security rules, definition of done. Many agents read this automatically. |
| `CLAUDE.md` | Same rules for Claude Code (imports `AGENTS.md`). |
| `DECISIONS.md` | Gaps in the documents that are already decided, plus a log the agent keeps up to date. |
| `docs/` | Your project brief, SRS, architecture, and database/API/wireframes documents, plus all diagrams in `docs/diagrams/`. |
| `db/migrations/001_init.sql` | The approved database schema (taken from the Week 4 DDL). |
| `.env.example`, `docker-compose.yml`, `.gitignore` | Local setup starters. |
| `prompts/` | The master prompt and 10 phase prompts. |

## How to start (about 15 minutes)

1. Install: Node.js LTS (20 or newer), Git, Docker Desktop (for the local database), and your coding agent.
2. Create a new folder `quickmenu-qr`, unzip this kit into it, run `git init`, and make a first commit.
3. Open the folder in your coding agent.
4. Paste the contents of `prompts/00_MASTER_PROMPT.md`. The agent reads all documents and answers with a plan and questions. **Read its answer.** Fix anything wrong before continuing.
5. Send `prompts/01_SCAFFOLD.md`. When the agent finishes, run the commands yourself and check the acceptance criteria listed in that prompt.
6. Commit. Then continue with 02, 03, and so on, **one phase at a time**.

## Working rules that save you time

- **One phase per chat session** if your tool allows it. Start each new session with: "Read AGENTS.md and DECISIONS.md, then read the files named in the prompt below." Then paste the phase prompt.
- **Always run it yourself:** `npm run lint`, `npm run typecheck`, `npm test`, and open the app. Never accept "it should work".
- **Review the diff** before committing; ask the agent to explain anything you do not understand. You will need to explain it to your professor.
- **Commit after every passing phase** (and tag it, for example `week5`). If a phase goes wrong, `git reset` to the last good commit and retry with a clearer prompt.
- **Keep secrets out of Git.** Real keys go only in `.env` files, which are ignored.
- **If the agent wants to change the design** (new endpoint, renamed field), make it write the reason in `DECISIONS.md` and update the document in `docs/`, so your documents stay true. Update your Week 2 to 4 documents before submitting final versions.
- **Do not skip the tests.** They are how you prove the requirements to your professor (and they are part of your Week reports).

## Suggested mapping to your weekly reports

Weeks 5 to 12 deliverables are set by your portal, so match this table to each week's screenshot and adjust.

| Week | Likely focus | Prompts |
|---|---|---|
| 5 | Repository, tooling, database, authentication | 01, 02, 03 |
| 6 | Menu management API and owner dashboard (Month 1 goal) | 04, 07 (menu part) |
| 7 | Tables and QR, public menu, translation | 05, 07 (tables part) |
| 8 | Customer mobile PWA (Month 2 goal) | 08 |
| 9 | Orders and real-time backend | 06 |
| 10 | Kitchen display (Month 3 goal) | 09 |
| 11 | Testing, security, performance, deployment | 10 |
| 12 | Pilot with 5 cafes/restaurants (Month 4 goal), final report | 10 (pilot kit) |

Tip: phase 06 (orders) is the riskiest part. If you are behind schedule, do it earlier, right after phase 05, and build the customer app (08) and kitchen display (09) against it.

## Document gaps found while preparing this kit
These are already resolved in `DECISIONS.md` (D-1 to D-8): the tracking token vs idempotent replay, refresh-token storage, translation and email providers, variant rules on ordering, the public menu WebSocket room, order-number growth, and public menu caching. Mention them to your professor as "design refinements discovered during implementation".

## If something is unclear
Ask the agent: "Which document section is this based on?" Every task points to the sections it comes from.
